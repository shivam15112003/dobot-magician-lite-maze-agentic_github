# Ubuntu build — Agentic AI (Gemini) scene + local planner + camera support
- One input: `--start-color {red|green}`
- Default Z work: 120 mm
- Camera via `--camera-index` (interactive or headless)
